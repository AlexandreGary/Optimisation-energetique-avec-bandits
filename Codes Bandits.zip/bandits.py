###################################################################################
                                   #### Importations ####
###################################################################################


import pandas as pd
from math import *
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
import dateutil.parser
import re
import contextualbandits
import time
from IPython.core.interactiveshell import InteractiveShell

from scipy import stats as stats
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, make_scorer
import statsmodels.api as sm
import statsmodels.tsa.stattools as tsa

pd.set_option('display.max_columns', 80)
pd.set_option('expand_frame_repr', True)

sns.set_palette("hls")




###################################################################################
                                #### Fonction generales ####
###################################################################################





def PlayArm(iter,arm,S,visitor_reward):
    #mean
    arm = int(arm)
    iter = int(iter)
    S[0,arm] = (S[0,arm]*S[1,arm] + visitor_reward[iter,arm]) / (S[1,arm]+1)
    #play
    S[1,arm] += 1
    return S

def ControlDataMissing(visitor_reward):
    t = pd.DataFrame.isnull(visitor_reward)
    c = sum(pd.DataFrame.sum(t))
    
    if c > 0 :
        raise ValueError('Missing data in arm results database')
        
def DataControlK(visitor_reward, K = None):
    if K == None :
        K = np.shape(visitor_reward)[1]
    
    if K < 2 :
        raise ValueError('Arm must be superior or equal to 2')
    
    if np.shape(visitor_reward)[1] != K :
        raise ValueError('Each arm need a result')
        
def BanditRewardControl(visitor_reward, K=None):
    DataControlK(visitor_reward,K)
    ControlDataMissing(visitor_reward)
    
def DataControlContextReward(dt, visitor_reward):
    
    # Match size control
    if(np.shape(dt)[0] != np.shape(visitor_reward)[0]):
        raise ValueError("Number of rows in contextual data and reward data are not equal")
     
    
    
    
    
    
    
###################################################################################        
                                    #### Calcul regret ####
###################################################################################




def SimpleRegret(choice,visitor_reward):
    visitor_reward
    n = visitor_reward.shape[0]
    regret = np.zeros(n)
    for i in range(n):
        regret[i] = RegretValue(choice[i],np.array(visitor_reward)[i,:])
    return regret

def RegretValue(arm, vec_visitor_reward):
    return max(vec_visitor_reward) - vec_visitor_reward[int(arm)]

def cumulativeRegret(choice,visitor_reward):
    regret = SimpleRegret(choice,visitor_reward)
    return np.cumsum(regret)



###################################################################################
                                   #### Bandit uniforme ####
###################################################################################



def UniformBandit(visitor_reward, K = None):
    
    if K == None :
        K = visitor_reward.shape[1]
    
    # control :
    BanditRewardControl(visitor_reward,K)
    
    # data formating :
    visitor_reward = np.array(visitor_reward)
    
    # keep list of choices :
    n = np.shape(visitor_reward)[0]
    choice = np.zeros(n)
    S = np.zeros((2,K))
    
    tic = time.time()
    
    if K > n :
        print("Warning : more arm than visitor")
        
        for j in range(n):
            S = PlayArm(j,j,S)
        choice = np.arange(1,n+1,1)
        toc = tme.time()
        return [S,choice,toc-tic]
    
    else :
        
        for i in range(n):
            choice[i] = ((i+1)%K)
            S = PlayArm(i,i%K, S, visitor_reward)
        toc = time.time()
        
        return [S,choice,toc-tic]

    
    
###################################################################################    
                                #### Epsilon greedy ####
###################################################################################



def ConditionForEpsilonGreedy(S, epsilon=0.25,K=None):
    if K == None :
        K = np.shape(S)[1]
        
    # choose the best with 1-epsilon proba. 0 : best arm, 1  : other arm
    u = np.random.binomial(1,1-epsilon)
    
    # the best one have been choose
    if u == 1 :
        return int(np.argmax(S[0,:]))
    
    # randomly select another arm :
    else :
        m = np.argmax(S[0,:])
        l = np.arange(0,K,1)
        l = np.delete(l,m)
        return np.random.choice(l)
    
def EpsilonGreedy(visitor_reward0, K = None, epsilon = 0.25):
    if K == None :
        K = np.shape(visitor_reward0)[1]
    # Control :
    BanditRewardControl(visitor_reward = visitor_reward0, K = K)
    
    # data formating :
    visitor_reward = np.array(visitor_reward0)
    
    # keep list of choice :
    choice = np.zeros(np.shape(visitor_reward)[0])
    S = np.zeros((2,K))
    tic = time.time()
    
    if K >= np.shape(visitor_reward)[0] :
        print(" Warning : More arm than visitors !")
        
        for j in range(np.shape(visitor_reward)[0]):
            S = PlayArm(j,j,S,visitor_reward)
        
        choice[0:np.shape(visitor_reward)[0]] = np.arange(0,np.shape(visitor_reward)[0]+1,1)
        
        if K > np.shape(visitor_reward)[0] :
            S[:,j:K] = 0
        
        return [S, choice]
    
    else :
        
        # Initialisation
        for j in range(K):
            S = PlayArm(j, j, S, visitor_reward)
            choice[1:K] = np.arange(1,K,1)

        for i in range(K,np.shape(visitor_reward)[0]):
            choice[i] = ConditionForEpsilonGreedy(S, epsilon)
            S = PlayArm(i,choice[i],S,visitor_reward)

            
        toc = time.time()
        
        # coef estimate :
        theta_hat = S[0,:]
        
        # real coef :
        theta = pd.DataFrame.mean(visitor_reward0)
        
        return [S, choice, toc-tic, theta_hat, theta]

###################################################################################
                                       #### LINUCB ####
###################################################################################




def ReturnRealTheta(dt, visitor_reward, option = 'linear'):
    
    K = np.shape(visitor_reward)[1]
    n_f = np.shape(dt)[1]
    theta = []
    
    temp = pd.DataFrame.copy(dt)
    if option == 'linear' :
        for i in range(K):
            pred = visitor_reward[:,i]
            reg = sm.OLS(endog = pred,exog = temp).fit() #Resutats differents par rapport a la regression en R
            theta.append(reg.params)
            
            
    # A faire : regression log
    
    else :
        raise ValueError("Regression non lineaire")
    
    return theta

def LINUCB(dt, visitor_reward0, alpha = None, K = None, IsRewardAreBoolean = False):

    if alpha == None :
        alpha = 1
    if K == None :
        K = np.shape(visitor_reward0)[1]
    if IsRewardAreBoolean == None :
        IsRewardAreBoolean = False
    # control data :
    DataControlK(visitor_reward0,K)
    DataControlContextReward(dt, visitor_reward0)
    
    # Data Formating :
    visitor_reward = np.array(visitor_reward0)
    
    # ContextMatrix :
    D = np.array(dt)
    n = np.shape(dt)[0]
    n_f = np.shape(D)[1]
    
    # Keep the past choice for regression :
    choices = np.zeros(n)
    rewards = np.zeros(n)
    proba = np.zeros(n)
    
    # Parameters to modelize :
    theta_hat = np.zeros((K,n_f))
    theta_hat_colnames = dt.columns
    theta_hat_index = visitor_reward0.columns
    
    # Regression variable :
    b = np.zeros((K,n_f))
    A = np.zeros((K,n_f,n_f))
    
    # Tempory variable :
    p = np.zeros(K)
    
    # Time keeper :
    tic = time.time()
    
    #Initialization :
    for j in range(K):
        A[j,:,:] = np.eye(n_f)
    
    for i in range(K):
        x_i = D[i,:]
        x_i0 = np.reshape(x_i,(n_f,1))
        for j in range(K):
            A_inv = np.linalg.inv(A[j,:,:])
            theta_hat[j,:] = A_inv.dot(b[j,:])
            ta = np.transpose(x_i0).dot(A_inv).dot(x_i0)
            a_upper_ci = alpha * sqrt(ta)
            a_mean = theta_hat[j,:].dot(x_i)
            p[j] = a_mean + a_upper_ci
        
        # Choose the highest :
        choices[i] = i

        # save probability :
        proba[i] = p[i]
        
        # see what kind of result we get :
        rewards[i] = visitor_reward[i,int(choices[i])]
        
        # update the input vector :
        x_it = np.transpose(x_i0)
        A[int(choices[i]),:,:] += x_i0.dot(x_it)
        b[int(choices[i])] += x_i*rewards[i]
    

    for i in range(K,n):
        x_i = np.array(D[i,:])
        x_i0 = np.reshape(x_i,(n_f,1))
        for j in range(K):
            A_inv = np.linalg.inv(A[j,:,:])
            theta_hat[j,:] = A_inv.dot(b[j,:])
            ta = np.transpose(x_i0).dot(A_inv).dot(x_i)
            a_upper_ci = alpha * sqrt(ta)
            a_mean = theta_hat[j,:].dot(x_i)
            p[j] = a_mean + a_upper_ci
            
        # choose the highest :
        choices[i] = np.argmax(p)
        
        # save probability :
        proba[i] = max(p)
        
        # see what kind of result we get :
        rewards[i] = visitor_reward[i,int(choices[i])]
        
        # update the input vector :
        x_it = np.transpose(x_i0)
        A[int(choices[i]),:,:] += x_i0.dot(x_it)
        b[int(choices[i])] += x_i*rewards[i]
        

    tac = time.time()

    # return real theta from a rigid regression :
    if IsRewardAreBoolean ==  False : 
        theta = ReturnRealTheta(dt=dt,visitor_reward=visitor_reward, option = 'linear')
    
    # return real theta from logit regression :
    if IsRewardAreBoolean ==  True : 
        theta = ReturnRealTheta(dt=dt,visitor_reward=visitor_reward, option = 'linear') 
    
    theta_hat = pd.DataFrame(theta_hat)
    theta_hat.columns = theta_hat_colnames
    theta_hat.index = theta_hat_index
    
    theta = pd.DataFrame(theta)
    theta.columns = theta_hat_colnames
    theta.index = theta_hat_index
    
    # return data, models, groups and results :
    return [proba, theta_hat, theta, choices, tac - tic]




###################################################################################
                                     #### UCB ####
###################################################################################



def ProbaMaxForUCB(S,iter,alpha,K):
    choice = np.zeros(K)
    for j in range(K):
        choice[j] = S[0,j] + alpha*sqrt(2*log(iter+1)/S[1,j])
    return choice

def ConditionForUCB(S,iter,alpha,K):
    return np.argmax(ProbaMaxForUCB(S,iter,alpha,K))

def UCB(visitor_reward0, K = None, alpha = None):
    
    if K == None :
        K = visitor_reward0.shape[1]
    if alpha == None :
        alpha = 1
    
    BanditRewardControl(visitor_reward0, K)
    
    # data formating
    visitor_reward = np.array(visitor_reward0)
    n = np.shape(visitor_reward)[0]

    # keep list of choices
    choice = np.zeros(n)
    proba = np.zeros(n)
    S = np.zeros((2,K))
    tic = time.time()
    
    if K >= n :
        print("Warning : More arms than visitors")
        
        for j in range(n):
            proba[j] = max(ProbaMaxForUCB(S,j,alpha,K))
            S = PlayArm(j,j,S,visitor_reward)
        choice = np.arange(0,n+1,1)

        if K > n :
            S[:,j:K] = 0
        return [S,choice]
    else :
        
        # initialisation
        
        for j in range(K):
            proba[j] = max(ProbaMaxForUCB(S,j,alpha,K))
            S = PlayArm(j,j,S,visitor_reward)
            choice[j] = j
            
        for i in range(K,n):
            choice[i] = ConditionForUCB(S,i,alpha,K)
            proba[i] = max(ProbaMaxForUCB(S,i,alpha,K))
            S = PlayArm(i,choice[i],S,visitor_reward)
            
        toc = time.time()
        
        # coef estimate
        theta_hat = S[0,:]
        
        # real coef
        theta = pd.DataFrame.mean(visitor_reward0)
        
        return [S,choice,proba,toc-tic,theta_hat,theta]
    
